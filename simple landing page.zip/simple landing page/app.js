const trans = document.getElementById("trans")
const navlist = document.getElementById("navlist")

trans.addEventListener("click" , ()=>{
    
    navlist.classList.toggle("navlist-active")
})